# Stworz funkcje ktora jako parametr przyjmuje lancuch znakow
# i zwroci slownik z dwoma pozycjami:
# klucze: "samogloski" i "spolgloski"
# wartosci: lista samoglosek i lista spolglosek


#print(foo("Ala ma kota"))

# {"samogloski": ["A", "a", "a", "o", "a"],
#  "spolgloski": ["l", "m", "k", "t"]}

def split_word(word):
    #TODO
    pass

print(split_word("AlaMaKota"))


