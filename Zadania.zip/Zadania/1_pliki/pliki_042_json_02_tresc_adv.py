# Stworz funkcje konwertujaca plik menu.json do obiektu klasy Menu.
#
# Struktura obiektu powinna wygladac nastepujaco:
#
# class Menu:
#     header = "string"
#     items = ["string1", "string2", "string3"]
#
# pola klasy powinny zostac wygenerowane automatycznie na podstawie zawartosci slownika stworzonego z pliku json
#
#
# przydatny moze okazac sie parametr object_hook
