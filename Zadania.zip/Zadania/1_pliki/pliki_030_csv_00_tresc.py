# Stworz funkcje wczytujaca rekokrdy z pliku csv do listy slownikow
# DictReader(f, delimiter=',', quoting=csv.QUOTE_NONE)

import csv
from pprint import pprint

def read_csv_to_list(path):
    #TODO
    pass

pprint(read_csv_to_list('resources/sales.csv'))