# Stworz funkcje ktra dla kazdego slowa znalezionego w poprzednim zadaniu zaloguje je w pliku "moj_log.log"
#
# log = logging.getLogger("my_handler")
# log.setLevel(logging.DEBUG)
# formatter = logging.Formatter('%(asctime)s %(message)s')
# handler = logging.XYZHandler()
# handler.setFormatter(formatter)
# log.addHandler(handler)
#

import logging
from pliki_011_text import get_words_from_file


def log_words():
    #TODO
    pass

log_words()