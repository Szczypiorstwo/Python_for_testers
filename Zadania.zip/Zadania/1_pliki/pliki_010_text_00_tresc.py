# Stworz funkcje wypisujaca kraje z ktorych pochadza
# osoby wymienione w pliku humans.txt

from pprint import pprint


def get_countries(file_to_open):
    #TODO
    pass


pprint(get_countries("resources/humans.txt"))
