
# Stworz funkcje tworzaca plik json zawierajacy
# {'date': 'RRRR-MM-DDT20:00:35',
# 'title': 'Imie - Moj post',
# 'status': 'publish',
# 'content': 'content',
# 'excerpt': 'Exceptional post!',
# 'format': 'standard'
# }

import json

def create_json():
    #TODO
    pass

create_json()
