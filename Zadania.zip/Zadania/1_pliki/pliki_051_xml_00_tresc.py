import xml.etree.ElementTree as ET

# Stworz funkcje ktora stworzy string w formacie xml:
# <Cars>
#   <car brand="Opel">
#       <model>Corsa</model>
#   </car>
# </Cars>
# Klocki: ElementTree, Element, SubElement

def create_xml_file(path):
    pass
    #TODO

create_xml_file("cars.xml")