import xml.etree.ElementTree as ET
import csv

# Wczytaj dane z pliku resources/sales.csv i zapisz je jako plik XML w podanym formacie:
# <Transtactions>
#   <Transaction date="1/2/09 6:17">
#       <product>Product1</product>
#       <price>1200</price>
#       <location>
#           <country>United Kingdom</country>
#           <city>Basildon</city>
#       </location>
#   </Transaction>
# </Transtactions>

def create_xml():
    pass
    #TODO

create_xml()
