# Zainstaluj mysqlclient
# Stworz klase odpowiedzialna za obsluge polaczenia z baza MqSql Wordpressa
# Bazując na metodzie print_owners z poprzedniego zadania stworz funkcje
# wypisujaca wszystkie posty (baza wordpress)
# https://github.com/PyMySQL/mysqlclient-python/blob/master/doc/user_guide.rst#mysqldb
# host="x.x.x.x", port=3306, user="test", passwd="test", db="wordpress"